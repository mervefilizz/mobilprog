package com.mervefiliz.mobilprogramlamavize;

public class Person {
    private String namelastname;
    private String schoolnumber;
    private String image;

    public Person() {
    }

    public Person(String namelastname, String schoolnumber, String image) {
        this.namelastname = namelastname;
        this.schoolnumber = schoolnumber;
        this.image = image;
    }

    public String getNamelastname() {
        return namelastname;
    }

    public void setNamelastname(String namelastname) {
        this.namelastname = namelastname;
    }

    public String getSchoolnumber() {
        return schoolnumber;
    }

    public void setSchoolnumber(String schoolnumber) {
        this.schoolnumber = schoolnumber;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

}
