package com.mervefiliz.mobilprogramlamavize;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Shader;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.mervefiliz.mobilprogramlamavize.ContactFields.NumberField;

import java.util.LinkedList;
import java.util.Set;

import jagerfield.mobilecontactslibrary.Contact.Contact;
import jagerfield.mobilecontactslibrary.ElementContainers.NumberContainer;

public class SendSmsActivity extends AppCompatActivity {
    private ImageView imageViewBack;
    private EditText editTextTextMultiLine;
    private Button button2;
    private RadioButton radioButton4, radioButton5, radioButton6;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    private Set<String> phonenumberslist;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_sms);

        imageViewBack = findViewById(R.id.imageViewBack);
        editTextTextMultiLine = findViewById(R.id.editTextTextMultiLine);
        button2 = findViewById(R.id.button2);

        radioButton4 = findViewById(R.id.radioButton4);
        radioButton5 = findViewById(R.id.radioButton5);
        radioButton6 = findViewById(R.id.radioButton6);

        String controller = getIntent().getStringExtra("controller");

        sharedPreferences = getSharedPreferences(controller, Context.MODE_PRIVATE);

        phonenumberslist = sharedPreferences.getStringSet("phonenumbers", null);

        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SendSmsActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.e("Controller", controller);

                if (radioButton4.isChecked() && radioButton4.getText().toString().equals(controller)) {
                    for (String number : PersonAdapter.phoneNumbersList
                    ) {
                        SmsManager sms = SmsManager.getDefault();
                        sms.sendTextMessage(number, null, editTextTextMultiLine.getText().toString().trim(), null,null);

                        Toast.makeText(SendSmsActivity.this, "Sms gönderiliyor", Toast.LENGTH_LONG).show();
                    }
                }else if (radioButton5.isChecked() && radioButton5.getText().toString().equals(controller)) {
                    for (String number : PersonAdapter.phoneNumbersList
                    ) {
                        SmsManager sms = SmsManager.getDefault();
                        sms.sendTextMessage(number, null, editTextTextMultiLine.getText().toString().trim(), null,null);

                        Toast.makeText(SendSmsActivity.this, "Sms gönderiliyor", Toast.LENGTH_LONG).show();
                    }
                }else if (radioButton6.isChecked() && radioButton6.getText().toString().equals(controller)) {
                    for (String number : PersonAdapter.phoneNumbersList
                    ) {
                        SmsManager sms = SmsManager.getDefault();
                        sms.sendTextMessage(number, null, editTextTextMultiLine.getText().toString().trim(), null,null);

                        Toast.makeText(SendSmsActivity.this, "Sms gönderiliyor", Toast.LENGTH_LONG).show();
                    }
                }else {
                    Toast.makeText(SendSmsActivity.this, "Lütfen doğru grubu seçtiğinizden emin olunuz", Toast.LENGTH_LONG).show();
                }

            }
        });


    }
}