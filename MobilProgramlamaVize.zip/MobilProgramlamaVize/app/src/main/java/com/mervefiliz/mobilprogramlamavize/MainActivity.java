package com.mervefiliz.mobilprogramlamavize;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

import jagerfield.mobilecontactslibrary.Contact.Contact;
import jagerfield.mobilecontactslibrary.ImportContacts;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    @SuppressLint("StaticFieldLeak")
    public static RadioButton radioButton, radioButton2, radioButton3;
    private Button button, button4;

    private PersonAdapter personAdapter;
    private ArrayList<Contact> contactArrayList = new ArrayList<>();

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    private String controller = "";

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        radioButton = findViewById(R.id.radioButton);
        radioButton2 = findViewById(R.id.radioButton2);
        radioButton3 = findViewById(R.id.radioButton3);
        button = findViewById(R.id.button);
        button4 = findViewById(R.id.button4);

        ImportContacts importContacts = new ImportContacts(MainActivity.this);

        contactArrayList = importContacts.getContacts();

        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);

        personAdapter = new PersonAdapter(MainActivity.this, contactArrayList);
        personAdapter.notifyDataSetChanged();
        recyclerView.setAdapter(personAdapter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (radioButton.isChecked()) {
                    sharedPreferences = getSharedPreferences("iş", Context.MODE_PRIVATE);
                    editor = sharedPreferences.edit();
                    controller = "İş   ";
                }else if (radioButton2.isChecked()) {
                    sharedPreferences = getSharedPreferences("okul", Context.MODE_PRIVATE);
                    editor = sharedPreferences.edit();
                    controller = "Okul   ";
                }else if (radioButton3.isChecked()) {
                    sharedPreferences = getSharedPreferences("yurt", Context.MODE_PRIVATE);
                    editor = sharedPreferences.edit();
                    controller = "Yurt   ";
                }

                Set<String> phonenumberslist = PersonAdapter.phoneNumbersList;

                editor.putStringSet("phonenumbers", phonenumberslist);
                editor.commit();

                Intent intent = new Intent(MainActivity.this, SendSmsActivity.class);
                intent.putExtra("controller", controller);
                startActivity(intent);
                finish();
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (radioButton.isChecked()) {
                    sharedPreferences = getSharedPreferences("iş", Context.MODE_PRIVATE);
                    editor = sharedPreferences.edit();
                    editor.clear();
                    editor.commit();

                    Toast.makeText(MainActivity.this, "İş grubundaki kayıt başarıyla silindi", Toast.LENGTH_LONG).show();

                }else if (radioButton2.isChecked()) {
                    sharedPreferences = getSharedPreferences("okul", Context.MODE_PRIVATE);
                    editor = sharedPreferences.edit();
                    editor.clear();
                    editor.commit();

                    Toast.makeText(MainActivity.this, "Okul grubundaki kayıt başarıyla silindi", Toast.LENGTH_LONG).show();

                }else if (radioButton3.isChecked()) {
                    sharedPreferences = getSharedPreferences("yurt", Context.MODE_PRIVATE);
                    editor = sharedPreferences.edit();
                    editor.clear();
                    editor.commit();

                    Toast.makeText(MainActivity.this, "Yurt grubundaki kayıt başarıyla silindi", Toast.LENGTH_LONG).show();

                }else {
                    Toast.makeText(MainActivity.this, "Lütfen grup seçimi yapınız", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}