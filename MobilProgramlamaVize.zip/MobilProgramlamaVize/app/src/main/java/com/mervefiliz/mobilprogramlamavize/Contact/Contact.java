package com.mervefiliz.mobilprogramlamavize.contact;

import android.database.Cursor;

import com.google.gson.annotations.Expose;

import java.util.LinkedList;

import jagerfield.mobilecontactslibrary.ElementContainers.AddressContainer;
import jagerfield.mobilecontactslibrary.ElementContainers.EmailContainer;
import jagerfield.mobilecontactslibrary.ElementContainers.EventContainer;
import jagerfield.mobilecontactslibrary.ElementContainers.NickNameContainer;
import jagerfield.mobilecontactslibrary.ElementContainers.NoteContainer;
import jagerfield.mobilecontactslibrary.ElementContainers.NumberContainer;
import jagerfield.mobilecontactslibrary.ElementContainers.WebsiteContainer;
import jagerfield.mobilecontactslibrary.FieldContainer.FieldsContainer;

public class Contact implements FieldsContainer.IFieldContainer
{
    @Expose
    private final long id;
    @Expose
    private String  photoUri;
    @Expose
    private FieldsContainer fields;

    public Contact(long id)
    {
        this.id = id;
    }

    public String getPhotoUri() {
        return photoUri;
    }

    public void setPhotoUri(String photoUri)
    {
        if (photoUri==null)
        {
            photoUri = "";
        }

        this.photoUri = photoUri;
    }

    public void execute(Cursor mime, String cursor)
    {
        if (fields==null)
        {
            fields = new FieldsContainer();
        }

        fields.execute(cursor, mime);
    }

    public long getId() {
        return id;
    }

    @Override
    public String getDisplaydName()
    {
        if(fields==null){return "";}

        if (fields.getNameField()==null){return "";}

        if(fields.getNameField().getDisplaydName()==null){return "";}

        return fields.getNameField().getDisplaydName();
    }

    @Override
    public String getFirstName()
    {
        if(fields==null){return "";}

        if (fields.getNameField()==null){return "";}

        if(fields.getNameField().getFirstName()==null){return "";}

        return fields.getNameField().getFirstName();
    }

    @Override
    public String getLastName()
    {
        if(fields==null){return "";}

        if (fields.getNameField()==null){return "";}

        if(fields.getNameField().getLastName()==null){return "";}

        return fields.getNameField().getLastName();
    }

    @Override
    public LinkedList<NumberContainer> getNumbers()
    {
        return fields.getNumberField().getNumbers();
    }

    @Override
    public LinkedList<EmailContainer> getEmails() { return fields.getEmailField().getEmails(); }

    @Override
    public LinkedList<WebsiteContainer> getWebsites(){ return fields.getWebsiteField().getWebsites(); }

    @Override
    public LinkedList<AddressContainer> getAddresses() { return fields.getAddressField().getAddresses(); }

    @Override
    public LinkedList<NoteContainer> getNotes() { return fields.getNoteField().getNotes(); }

    @Override
    public LinkedList<EventContainer> getEvents() { return fields.getEventField().getEvents(); }

    @Override
    public LinkedList<NickNameContainer> getNickNames() { return fields.getNickNameField().getNickNames(); }



}
