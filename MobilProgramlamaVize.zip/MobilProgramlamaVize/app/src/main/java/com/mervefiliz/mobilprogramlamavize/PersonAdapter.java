package com.mervefiliz.mobilprogramlamavize;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import jagerfield.mobilecontactslibrary.Contact.Contact;
import jagerfield.mobilecontactslibrary.ElementContainers.NumberContainer;
import jp.wasabeef.glide.transformations.CropCircleTransformation;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.CardViewDesignThingsHolder>{
    private Context mContext;
    private ArrayList<Contact> personArrayList = new ArrayList<>();
    public static Set<String> phoneNumbersList = new HashSet<>();
    //public static ArrayList<String> phoneNumbersList = new ArrayList<>();

    public PersonAdapter(Context mContext, ArrayList<Contact> personArrayList) {
        this.mContext = mContext;
        this.personArrayList = personArrayList;
    }

    @NonNull
    @Override
    public CardViewDesignThingsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.cardview_person, parent, false);
        return new CardViewDesignThingsHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull CardViewDesignThingsHolder holder, int position) {
        Contact contact = personArrayList.get(position);

        holder.textViewCardPersonNameLastname.setText(contact.getFirstName()+" "+contact.getLastName());

        Glide.with(mContext)
                .load(contact.getPhotoUri())
                .bitmapTransform(new CropCircleTransformation(mContext))
                .into(holder.imageViewCardPerson);

        holder.cardViewPerson.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                if (MainActivity.radioButton.isChecked() || MainActivity.radioButton2.isChecked() || MainActivity.radioButton3.isChecked()) {
                    LinkedList<NumberContainer> numberFields = contact.getNumbers();

                    try {
                        phoneNumbersList.add(numberFields.get(0).getNormalizedNumber());
                        Toast.makeText(mContext, contact.getDisplaydName()+" adlı kişi başarıyla eklendi", Toast.LENGTH_LONG).show();
                    }catch (Exception e) {
                        Toast.makeText(mContext, "İlgili kişi seçilirken hata meydana geldi", Toast.LENGTH_LONG).show();
                    }

                }else {
                    Toast.makeText(mContext, "Lütfen grup seçimi yapınız", Toast.LENGTH_LONG).show();
                }

                return true;
            }
        });

    @Override
    public int getItemCount() {
        return personArrayList.size();
    }

    public static class CardViewDesignThingsHolder extends RecyclerView.ViewHolder {
        private CardView cardViewPerson;
        private TextView textViewCardPersonNameLastname;
        private ImageView imageViewCardPerson;

        public CardViewDesignThingsHolder(@NonNull View itemView) {
            super(itemView);
            cardViewPerson = itemView.findViewById(R.id.cardViewPerson);
            textViewCardPersonNameLastname = itemView.findViewById(R.id.textViewCardPersonNameLastname);
            imageViewCardPerson = itemView.findViewById(R.id.imageViewCardPerson);
        }
    }

}
