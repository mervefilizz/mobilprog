package com.mervefiliz.mobilprogramlamavize;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class SplashActivity extends AppCompatActivity {
    private EditText editTextSplashNameLastname, editTextSplashSchoolNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        editTextSplashNameLastname = findViewById(R.id.editTextSplashNameLastname);
        editTextSplashSchoolNumber = findViewById(R.id.editTextSplashSchoolNumber);

        editTextSplashNameLastname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                String namelastname = s.toString().toLowerCase();
                String schoolnumber = editTextSplashSchoolNumber.getText().toString();

                if (namelastname.length() != 0 && schoolnumber.length() != 0) {

                    pagetransition(namelastname, schoolnumber);

                }
            }
        });

        editTextSplashSchoolNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                String namelastname = editTextSplashNameLastname.getText().toString().toLowerCase();
                String schoolnumber = s.toString();

                if (schoolnumber.length() != 0 && namelastname.length() != 0) {

                    pagetransition(namelastname, schoolnumber);

                }
            }
        });

    }

    private void pagetransition(String namelastname, String schoolnumber) {

        if (namelastname.equals("Merve Filiz") && schoolnumber.equals("201813709015")) {

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }, 2000);

        }

    }
}